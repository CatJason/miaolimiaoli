---
title: 10. 二叉树-DFS (递归)
categoriesWeight: 1.1
weight: 10
categories: 
   - 0 - 算法
   - 0.0 - 算法模版
---
### 正文
```kotlin
class TreeNode(var value: Int) {
    var left: TreeNode? = null
    var right: TreeNode? = null
}

fun dfs(root: TreeNode?) {
    root?: return
    // visit() // 先序遍历
    dfs(root.left)  
    // visit() // 中序遍历
    dfs(root.right)  
    // visit() // 后序遍历
}

fun visit(root: TreeNode){
    println(root.value)
}
```

---
title: 12. 二叉树-BFS
categoriesWeight: 1.1
weight: 12
categories: 
   - 0 - 算法
   - 0.0 - 算法模版
---
### 正文
```kotlin
import java.util.LinkedList

class TreeNode(var value: Int) {
    var left: TreeNode? = null
    var right: TreeNode? = null
}

fun bfs(root: TreeNode?) {
    val queue: LinkedList<TreeNode> = LinkedList()
    queue.add(root)
    
    while (!queue.isEmpty()) {
        val node: TreeNode = queue.removeFirst()
        visit(node)

        if (node.left != null) {
            queue.add(node.left)
        }
        if (node.right != null) {
            queue.add(node.right)
        }
    }
}

fun visit(root: TreeNode){
    println(root.value)
}

```
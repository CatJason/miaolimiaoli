---
title: 15. 图-BFS
categoriesWeight: 1.1
weight: 15
categories: 
   - 0 - 算法
   - 0.0 - 算法模版
---
### 正文

```kotlin
import java.util.*

class Graph {
    private val adjacencyList: MutableMap<Int, MutableList<Int>> = HashMap()

    fun addEdge(src: Int, dest: Int) {
        adjacencyList.computeIfAbsent(src) { mutableListOf() }.add(dest)
        adjacencyList.computeIfAbsent(dest) { mutableListOf() }
    }

    fun bfs(startVertex: Int) {
        val visited = BooleanArray(adjacencyList.size)
        val queue: Queue<Int> = LinkedList()

        visited[startVertex] = true
        queue.offer(startVertex)

        while (!queue.isEmpty()) {
            val currentVertex = queue.poll()
            print("$currentVertex ")

            val neighbors = adjacencyList[currentVertex]
            if (neighbors != null) {
                for (neighbor in neighbors) {
                    if (!visited[neighbor]) {
                        visited[neighbor] = true
                        queue.offer(neighbor)
                    }
                }
            }
        }
    }
}

fun main() {
    val graph = Graph()
    graph.addEdge(0, 1)
    graph.addEdge(0, 2)
    graph.addEdge(1, 2)
    graph.addEdge(2, 0)
    graph.addEdge(2, 3)
    graph.addEdge(3, 3)

    println("BFS traversal starting from vertex 2:")
    graph.bfs(2)
}
```


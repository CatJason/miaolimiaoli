---
title: 协程核心概念的理解与应用(一)--翻译翻译什么是 CoroutineScope
categoriesWeight: 2.2
weight: 3
categories: 
   - 1 - Kotlin
   - 1.1 - Kotlin 协程
---

![图片描述](https://s21.ax1x.com/2024/03/09/pFymrC9.jpg)

作者：朕小猫与GPT4

# Android 如何在一个非 LifecycleOwner 的类中使用协程

在非`LifecycleOwner`的类中使用协程，你不能直接使用与生命周期相关的作用域，如`lifecycleScope`或`viewModelScope`。不过，你可以使用`CoroutineScope`来创建自己的作用域。使用`CoroutineScope`，你可以定义一个作用域，并指定一个`Dispatcher`来控制协程的执行线程。此外，你还需要手动管理协程的生命周期，以避免内存泄漏。

以下是如何在非`LifecycleOwner`类中使用协程的一个基本示例：

1. **定义协程作用域**：首先，定义一个协程作用域，通常是类的成员变量。这个作用域应当与你希望协程执行的生命周期绑定。例如，如果你在一个普通类中工作，你可能需要在类被销毁时取消所有协程。

    ```kotlin
    import kotlinx.coroutines.CoroutineScope
    import kotlinx.coroutines.Dispatchers
    import kotlinx.coroutines.Job

    class MyClass {
        private val job = Job()
        private val coroutineScope = CoroutineScope(Dispatchers.Main + job)
    }
    ```

2. **在协程作用域内启动协程**：使用定义的协程作用域启动协程，执行异步操作。

    ```kotlin
    import kotlinx.coroutines.launch

    class MyClass {
        // ...前面的代码

        fun doSomething() {
            coroutineScope.launch {
                // 在这里执行协程代码
            }
        }
    }
    ```

3. **管理协程生命周期**：为避免内存泄漏，确保在不需要协程运行时取消它们。如果你的类有一个明确的生命周期结束点（如自定义视图的`onDetachedFromWindow`或者一个对象的`close`方法），你应当在那里取消作用域中的所有协程。

    ```kotlin
    fun onDestroy() {
        job.cancel() // 取消与这个作用域相关的所有协程
    }
    ```

通过以上步骤，你可以在不依赖于`LifecycleOwner`的情况下，安全地在任何类中使用协程。记住，手动管理协程的生命周期是避免内存泄漏的关键。

# 如何理解 CoroutineContext 

`CoroutineContext`是Kotlin协程中用于持有协程相关配置的接口。它由一组元素组成，每个元素都实现了`CoroutineContext.Element`接口，并且通过一个唯一的`Key`进行标识。`CoroutineContext`的实现并不限于某些固定的子类，而是通过组合不同的`Element`实例来扩展其功能。这意味着`CoroutineContext`的“子类”实际上是指一系列标准库或自定义库中定义的实现了`CoroutineContext.Element`接口的类，这些类代表了不同的协程配置和特性。以下是一些常见的`CoroutineContext.Element`实现，它们在Kotlin协程的使用中扮演着关键角色：

1. **`Job`**: 控制协程的生命周期，允许启动、取消、和查询协程的状态。`Job`是协程工作的基本单位，可以被用来取消协程。

2. **`CoroutineDispatcher`**: 决定协程在哪个线程或线程池上执行。`Dispatchers.Main`、`Dispatchers.IO`、和`Dispatchers.Default`是最常用的几种调度器。

3. **`CoroutineName`**: 提供协程的名称，有助于调试。

4. **`CoroutineExceptionHandler`**: 定义了协程如何处理未捕获的异常。可以用来全局或局部地处理异常。

除了上述提到的标准元素外，开发者还可以实现自定义的`CoroutineContext.Element`来扩展协程的功能。每个元素都可以通过其`Key`加入到`CoroutineContext`中，同时保证`CoroutineContext`中的每个`Key`都是唯一的。

在实际应用中，这些元素可以通过`+`操作符组合在一起，形成一个包含多个配置的`CoroutineContext`，用于启动和管理协程。这种设计允许协程上下文在保持灵活性的同时，能够非常精确地控制协程的行为和环境。

# 协程的 + 号代表什么

```java
    /**
     * Returns a context containing elements from this context and elements from  other [context].
     * The elements from this context with the same key as in the other one are dropped.
     */
    public operator fun plus(context: CoroutineContext): CoroutineContext =
        if (context === EmptyCoroutineContext) this else // fast path -- avoid lambda creation
            context.fold(this) { acc, element ->
                val removed = acc.minusKey(element.key)
                if (removed === EmptyCoroutineContext) element else {
                    // make sure interceptor is always last in the context (and thus is fast to get when present)
                    val interceptor = removed[ContinuationInterceptor]
                    if (interceptor == null) CombinedContext(removed, element) else {
                        val left = removed.minusKey(ContinuationInterceptor)
                        if (left === EmptyCoroutineContext) CombinedContext(element, interceptor) else
                            CombinedContext(CombinedContext(left, element), interceptor)
                    }
                }
            }
```

这个`plus`函数是`CoroutineContext`的一个操作符函数，用于合并两个协程上下文（`CoroutineContext`），返回一个包含两者元素的新上下文。如果两个上下文中有相同键（`key`）的元素，那么原上下文（`this`）中的元素会被丢弃。这个函数的主要逻辑可以分解为几个关键步骤：

1. **快速路径检查**：如果要添加的上下文（`context`）是一个空的协程上下文（`EmptyCoroutineContext`），则直接返回当前上下文（`this`），因为没有新元素需要添加。

2. **遍历合并**：使用`fold`方法遍历`context`中的每个元素。`fold`接收一个初始累加值（这里是`this`，即当前上下文）和一个操作函数。操作函数定义了如何将`context`中的元素合并到累加值中。

3. **去除相同键的元素**：对于`context`中的每个元素，先从累加值（即目前合并的结果）中移除具有相同键的元素。这一步确保了如果有相同键的元素，那么`this`中的元素会被`context`中的元素替换。

4. **合并上下文**：如果移除相同键元素后的上下文是空的（`EmptyCoroutineContext`），则只添加当前遍历到的元素。否则，检查是否存在`ContinuationInterceptor`元素（协程拦截器），因为拦截器应当始终位于上下文中的最后，以便快速获取。

5. **调整拦截器位置**：如果存在`ContinuationInterceptor`，将其移动到合并后的上下文的最后。这涉及到在没有拦截器的剩余上下文中添加当前元素，然后再添加拦截器。

6. **返回新的合并上下文**：最终返回包含了`this`和`context`元素（且`context`中的元素优先）的新上下文。如果存在`ContinuationInterceptor`，确保它位于最后。

简而言之，这个函数通过合并两个协程上下文并调整元素顺序，确保了新上下文中不会有重复的键，且`ContinuationInterceptor`（如果存在）总是位于最后，以优化性能。

# 如何理解其中的 CoroutineContext 与 key，为什么context中的元素优先，为什么如果存在ContinuationInterceptor，确保它位于最后。

`CoroutineContext`在Kotlin协程中是一个关键概念，它是一组各种元素的集合，这些元素定义了协程的行为。每个元素都有一个`Key`，用于唯一标识该元素的类型，这样`CoroutineContext`就可以通过键值对的方式存储和检索协程的配置和状态信息。这里的“相同键（key）的元素”意味着两个元素属于同一类型，或者说执行相同的功能或角色。

### `CoroutineContext`和 key 

- **`CoroutineContext`**：是一个集合，包含了控制协程行为的各种元素，例如调度器（`Dispatcher`）、协程名称、协程的异常处理器等。每个元素通过一个唯一的键（**`Key`**）来识别，键通常由元素类型本身提供。

- **相同键的元素**：如果两个`CoroutineContext`元素具有相同的键，它们被视为同一类型的配置或状态信息。在合并上下文时，不能有重复键的元素，否则会产生冲突。

### 为什么`context`中的元素优先

在合并两个`CoroutineContext`时，如果存在相同键的元素，`context`参数中的元素会替换当前上下文（`this`）中的元素。这个设计选择是基于函数式编程中常见的不可变性原则，以及配置更新的需求：新提供的配置（即`context`参数中的）被认为是最新的，应优先于旧的配置。这样，开发者可以灵活更新协程的行为，而无需担心旧上下文的状态。

### 为什么`ContinuationInterceptor`位于最后

`ContinuationInterceptor`是`CoroutineContext`中的一个特殊元素，用于拦截协程的执行。它是协程调度器（如`Dispatchers.Main`）的基础，控制着协程的执行线程。将`ContinuationInterceptor`放在合并后的`CoroutineContext`的最后，是出于性能考虑：

- **快速访问**：协程在执行时频繁查询`ContinuationInterceptor`以确定执行线程。将其置于上下文的末尾可以优化这一查询过程，因为在`CoroutineContext`的实现中，较后的元素可以更快地被访问到。

- **避免冲突**：确保`ContinuationInterceptor`总是最后一个被添加，意味着即使合并多个上下文，也能保证只有一个有效的调度器在最终的上下文中生效，这避免了多个调度器可能导致的潜在冲突。

综上所述，`CoroutineContext`及其键的概念允许协程行为的灵活配置和更新，而在合并上下文时优先考虑新的元素以及保持`ContinuationInterceptor`在最后，是出于更新优先级和性能优化的考虑。


---
title: Kotlin 的协程本质到底什么
categoriesWeight: 2.2
weight: 1
categories: 
   - 1 - Kotlin
   - 1.1 - Kotlin 协程
---

### 正文

几乎就是用阻塞的写法来完成非阻塞的任务。
Kotlin-JVM中所谓的协程是假协程
Kotlin-JVM中所谓的 协程挂起 ，就是开启了一个子线程去执行任务

对于Java来说，不管你用什么方法，只要你没有魔改JVM，那么最终你代码里start几个线程，操作系统就会创建几个线程，是1比1的关系。
Kotlin官网中那个创建10w个Kotlin协程没有oom的例子其实有误导性，本质上那10w个Kotlin协程就是10w个并发任务仅此而已，他下面运行的就是一个单线程的线程池。你往一个线程池里面丢多少个任务都不会OOM的（前提是你的线程池创建的时候设定了对应的拒绝策略，否则无界队列下，任务过多一定会OOM），因为在运行的始终是那几个线程。

创建协程的方式有五种：

```css
GlobalScope.launch{}
launch{}
runBlocking{}
coroutineScope{}
async{}
```


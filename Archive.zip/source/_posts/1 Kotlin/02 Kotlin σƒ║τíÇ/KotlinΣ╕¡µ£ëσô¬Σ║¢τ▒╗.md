---
title: Kotlin中有哪些类
categoriesWeight: 2.1
weight: 2
categories: 
   - 1 - Kotlin
   - 1.0 - Kotlin 基础
---

在 Kotlin 中，类的概念是非常广泛的，包括各种类型的类设计用于不同的目的和场景。Kotlin 提供了丰富的类类型以支持现代软件开发的需要。下面是一些在 Kotlin 中常见的类类型：

### 1. **数据类（Data Class）**
数据类是专门用于存储数据的类。Kotlin 的数据类通过 `data` 关键字定义，它自动从所声明的属性中派生出 `equals()`、`hashCode()` 和 `toString()` 等方法，以及 `copy()` 函数和 `componentN()` 函数（按声明顺序对应于所有属性）。

```kotlin
data class User(val name: String, val age: Int)
```

### 2. **枚举类（Enum Class）**
枚举类用于定义一组命名常量。Kotlin 中的枚举不仅可以有属性，还可以有自己的方法。

```kotlin
enum class Direction {
    NORTH, SOUTH, EAST, WEST;
}
```

### 3. **密封类（Sealed Class）**
密封类用于表示受限的类层次结构，即一个值只能是有限集合中的某个类型，而不能是任何其他类型。这对于当你在使用 `when` 表达式时，想要确保覆盖所有可能的类型非常有用。

```kotlin
sealed class Expr
data class Const(val number: Double) : Expr()
data class Sum(val e1: Expr, val e2: Expr) : Expr()
object NotANumber : Expr()
```

### 4. **抽象类（Abstract Class）**
抽象类是不能被实例化的类，通常用作其他类的基类。抽象类可以包含抽象方法（没有实现的方法）和非抽象方法。

```kotlin
abstract class Vehicle {
    abstract fun drive()
    fun park() { println("Parked") }
}
```

### 5. **内部类（Inner Class）**
内部类是定义在另一个类内部的类。内部类持有其外部类的一个引用，因此可以访问其成员。

```kotlin
class Outer {
    private val bar: Int = 1
    inner class Inner {
        fun foo() = bar
    }
}
```

### 6. **嵌套类（Nested Class）**
与内部类相比，嵌套类没有对外部类的隐式引用。

```kotlin
class Outer {
    private val bar: Int = 1
    class Nested {
        fun foo() = 2
    }
}
```

### 7. **对象声明（Object Declaration）**
Kotlin 支持对象声明，这是实现单例模式的一种方式。对象声明的实例自动成为一个单例。

```kotlin
object DataProviderManager {
    fun registerDataProvider(provider: String) {
        println("Provider registered: $provider")
    }
}
```

### 8. **伴生对象（Companion Object）**
在 Kotlin 中，没有静态方法，但可以用伴生对象来模拟静态方法的效果。伴生对象的成员可以通过类名直接访问。

```kotlin
class MyClass {
    companion object Factory {
        fun create(): MyClass = MyClass()
    }
}
```

### 9. **接口（Interface）**
虽然不是类，但接口在 Kotlin 中用于定义可以由类实现或继承的协定。

```kotlin
interface Drivable {
    fun drive() {
        println("Driving")
    }
}
```

这些类类型展示了 Kotlin 语言的灵活性和现代特性，旨在提供简洁而强大的语法来支持各种编程范式和设计模式。

# 密封类

在 Kotlin 中，密封类（sealed class）是一种特殊的类，它用于表示严格的类层次结构。使用密封类，你可以定义一个类的可能的子类集合，而且这些子类只能在与密封类相同的文件中定义。这种限制确保了除文件内定义的子类之外，无法有其他子类存在，从而使得使用时更加安全和维护更加方便。

### 密封类的主要特点和优势：

1. **受限的继承**：
   - 密封类本身是抽象的，不能直接实例化，只能通过其子类进行实例化。
   - 所有的子类必须与密封类在同一个文件中声明，这提高了可维护性，因为所有扩展都在一个集中的位置。

2. **类型安全**：
   - 密封类非常适合用在 `when` 表达式中，因为它们可以确保覆盖所有可能的情况，不需要再添加一个 `else` 子句。这是因为编译器能够检测到所有定义的子类。

3. **更精确的控制**：
   - 使用密封类可以精确控制类的继承结构，这对于构建不可变数据类型和状态管理非常有用。

### 密封类的用法示例：

首先，定义一个密封类，然后在同一个文件中定义其所有子类：

```kotlin
sealed class Expr {
    data class Const(val number: Double) : Expr()
    data class Sum(val e1: Expr, val e2: Expr) : Expr()
    object NotANumber : Expr()
}

fun eval(expr: Expr): Double = when (expr) {
    is Expr.Const -> expr.number
    is Expr.Sum -> eval(expr.e1) + eval(expr.e2)
    Expr.NotANumber -> Double.NaN
}
```

在这个例子中，`Expr` 是一个密封类，有三个子类：`Const`、`Sum` 和 `NotANumber`。这使得 `eval` 函数可以安全地使用 `when` 表达式来处理所有可能的 `Expr` 类型，而不需要 `else` 分支，因为编译器知道所有可能的子类。

### 使用密封类的场景：

- **状态管理**：在应用程序状态管理或者在处理有限状态机（FSM）时，密封类提供了一种清晰的方式来表示所有可能的状态。
- **返回类型的多样性**：在函数需要返回多种类型的结果时，可以使用密封类来封装这些不同类型的返回值。
- **在模式匹配中增强类型安全**：如上面示例中的 `eval` 函数，使用密封类可以确保 `when` 表达式已经处理了所有可能的情况，这在处理复杂的逻辑分支时非常有帮助。

通过这种方式，Kotlin 的密封类增加了代码的安全性和清晰度，特别是在需要表达一个有限的类层次结构时。

# 内联类

Kotlin 1.3 引入了内联类，主要目的是提供一种无开销的抽象方式。内联类允许你创建一个包含单个属性的类，当这个类被使用时，它会在编译时被内联，即直接替换为它包含的那个值，从而避免了额外的内存分配和间接访问。

### 内联类的定义和使用

内联类定义时需要使用 `inline` 关键字，且必须有一个主构造函数，该构造函数恰好接收一个参数：

```kotlin
inline class Password(val value: String)
```

这里的 `Password` 类包裹了一个字符串，但在编译后，Kotlin 编译器会尽可能将 `Password` 类的实例替换为简单的 `String` 类型，从而减少对象创建的开销。当你在代码中使用 `Password` 类型时，例如将它作为函数参数或从函数中返回时，实际上传递的将是一个 `String` 类型。

### 内联类的特点和优势

1. **性能优化**：内联类主要用于性能优化，可以避免对象分配，并减少方法调用的层次。
2. **类型安全**：虽然内联类在运行时表现为它们包装的类型（例如 `String` 或 `Int`），但在编译时，它们是不同的类型。这意味着你可以用它们来实现类型安全的操作，例如防止将普通字符串与经过验证的密码字符串混淆。
3. **限制**：内联类不能有初始化块 (`init` 块)，它们也不能包含其他属性或构造函数。此外，内联类可以实现接口，但不能从其他类继承。

### 示例代码

```kotlin
inline class Password(val value: String)

fun takePassword(password: Password) {
    println("Password is ${password.value}")
}

fun main() {
    val password = Password("my_secret_password")
    takePassword(password)  // 在这里，password 被内联，实际传递的是一个 String 对象
}
```

在这个例子中，尽管我们定义了一个名为 `Password` 的内联类，并在函数 `takePassword` 中使用它，实际上，在编译后，这些函数调用会直接使用 `String` 类型，而不会有任何包装和解包的性能开销。

### 结论

内联类是 Kotlin 提供的一种非常有用的特性，特别适合那些需要通过类型来提供更丰富语义但又不想引入运行时开销的场景。通过内联类，Kotlin 开发者可以在享受类型安全的同时，保持代码的高性能。
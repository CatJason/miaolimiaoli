---
title: Kotlin中的自动拆装箱
categoriesWeight: 2.1
weight: 2
categories: 
   - 1 - Kotlin
   - 1.0 - Kotlin 基础
---

在 Kotlin 中，对于基本数据类型的包装类，比如 `Integer`、`Boolean` 等，Kotlin 设计了一套特殊的类，被称为原生类型的包装类或者叫做原生类型的对象，例如 `Int`、`Boolean` 等。这些类的行为表现得如同 Java 的基本类型，同时它们具备了对象的一些特性。在编译阶段，Kotlin 会尽量使用 JVM 的原生类型来提高性能，但在需要时（例如作为泛型参数时），这些原生类型会自动装箱。

### 自动装箱与拆箱

Kotlin 处理原生类型和装箱类型的自动转换，以保证性能同时提供丰富的类库支持。这个过程包括两个部分：自动装箱（boxing）和自动拆箱（unboxing）。

- **装箱（Boxing）**：当一个原生类型的值需要作为对象处理时，它会自动被装入对应的包装类。例如，当你将一个 `int` 值放入一个泛型集合如 `List<Int>` 时，这个值会自动被装箱成 `Integer`。
- **拆箱（Unboxing）**：当从对象中需要一个原生类型的值时，这个包装对象会自动被拆箱。例如，从 `List<Int>` 中取出一个元素时，它会自动从 `Integer` 转换为 `int`。

### 示例

```kotlin
val list: List<Int> = listOf(1, 2, 3)  // 装箱
val x: Int = list[0]                   // 拆箱
```

在上面的例子中，整数列表中的数字自动被装箱成 `Integer` 类型的对象以存入 `List<Int>`。当从列表中检索一个整数时，它自动拆箱回 `Int` 类型。

### 注意事项

虽然 Kotlin 试图隐藏装箱和拆箱的复杂性，但在某些情况下，装箱对象的身份不会保留。例如，两个独立装箱的整数可能不会在内存中具有相同的引用：

```kotlin
val a: Int = 1000
val boxedA: Int? = a
val anotherBoxedA: Int? = a
println(boxedA === anotherBoxedA)  // 可能输出 false
```

在上面的代码中，`boxedA` 和 `anotherBoxedA` 是相同原始值的两个独立的装箱实例。使用 `===` 比较它们的引用时可能得到 `false`，因为它们可能指向不同的对象。

### 总结

Kotlin 在编写代码时提供了类似于基本数据类型的简洁性和效率，同时也保留了对象的灵活性。通过自动装箱和拆箱，Kotlin 旨在提供无缝的集合操作和泛型支持，同时减少需要程序员关注的底层细节。
---
title: ArrayDeque 的接口
categoriesWeight: 3.1
weight: 1
categories: 
   - 2 - Java
   - 2.0 - Java 基础
---

### 正文

`ArrayDeque` 实现了 `Deque` 接口，该接口继承自 `Queue` 接口。下面是 `Deque` 接口中定义的一些主要方法：

1. 添加元素操作：
   - `addFirst(element: E)`：将元素添加到双端队列的开头。
   - `addLast(element: E)`：将元素添加到双端队列的末尾。
   - `offerFirst(element: E)`：将元素添加到双端队列的开头，并返回是否成功。
   - `offerLast(element: E)`：将元素添加到双端队列的末尾，并返回是否成功。

2. 获取元素操作：
   - `getFirst(): E`：获取双端队列的第一个元素，但不删除它。
   - `getLast(): E`：获取双端队列的最后一个元素，但不删除它。
   - `peekFirst(): E`：获取双端队列的第一个元素，如果队列为空则返回 null。
   - `peekLast(): E`：获取双端队列的最后一个元素，如果队列为空则返回 null。

3. 移除元素操作：
   - `removeFirst(): E`：移除并返回双端队列的第一个元素。
   - `removeLast(): E`：移除并返回双端队列的最后一个元素。
   - `pollFirst(): E`：移除并返回双端队列的第一个元素，如果队列为空则返回 null。
   - `pollLast(): E`：移除并返回双端队列的最后一个元素，如果队列为空则返回 null。

此外，`ArrayDeque` 还实现了 `Queue` 接口中定义的方法，如 `offer(element: E)`、`remove(): E`、`poll(): E` 等。

需要注意的是，`ArrayDeque` 是一个可变大小的数组双端队列，可以在队列的两端进行高效的插入和删除操作，同时也支持随机访问。
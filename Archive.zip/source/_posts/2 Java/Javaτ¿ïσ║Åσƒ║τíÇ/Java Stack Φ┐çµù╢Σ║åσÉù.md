---
title: Java Stack 过时了吗
categoriesWeight: 3.1
weight: 3
categories: 
   - 2 - Java
   - 2.0 - Java 基础
---

### 正文

在 Java 中，`Stack` 类并没有过时，仍然可以使用。然而，根据 Java 官方文档的建议，推荐使用 `Deque` 接口的实现类 `ArrayDeque` 来代替 `Stack`。

`Stack` 类是基于向量（`Vector`）实现的，而 `Vector` 是线程安全的、同步的，因此在性能上可能会有一些开销。而 `ArrayDeque` 是基于数组实现的双端队列，性能更高，并且在大多数情况下能够提供与 `Stack` 类相同的功能。

此外，`Deque` 接口提供了更丰富的操作方法，例如在队首或队尾插入、删除元素等，使得其更灵活且更符合现代编程的需求。

因此，尽管 `Stack` 类仍然可用，但在新的代码中，推荐使用 `ArrayDeque` 或其他实现了 `Deque` 接口的类来代替 `Stack`。
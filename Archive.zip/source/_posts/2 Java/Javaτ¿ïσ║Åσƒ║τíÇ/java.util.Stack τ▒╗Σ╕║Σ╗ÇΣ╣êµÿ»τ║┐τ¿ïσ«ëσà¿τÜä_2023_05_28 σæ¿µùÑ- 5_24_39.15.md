---
title: java.util.Stack 类为什么是线程安全的
categoriesWeight: 3.1
weight: 4
categories: 
   - 2 - Java
   - 2.0 - Java 基础
---
### 正文

在Java中，`java.util.Stack` 类是线程安全的，这是因为它是通过在每个方法上添加`synchronized`关键字来实现同步的。
`synchronized`关键字可以确保在同一时间只有一个线程可以访问被标记为`synchronized`的方法或代码块。
当一个线程执行一个被`synchronized`关键字修饰的方法时，它将获得一个锁，其他线程必须等待该锁释放才能访问相同的方法。
这样可以确保在任何给定的时刻只有一个线程可以修改`Stack`的状态，从而防止并发访问导致的数据不一致或竞态条件。
然而，需要注意的是，虽然`Stack`类本身是线程安全的，但在某些情况下，使用`synchronized`关键字可能会降低性能，特别是在高并发环境下。
因此，在Java中，推荐使用`java.util.concurrent`包提供的并发集合类，如`java.util.concurrent.ArrayDeque`或`java.util.concurrent.LinkedBlockingDeque`，它们提供了更高效和灵活的线程安全操作。
---
title: 06-Android-Framework-AMS专项-Activity生命周期事物封装
categoriesWeight: 4.1
weight: 6
categories: 
   - 3 - Android
   - 3.1 - Framework
---

解读完启动参数之后，就进入到由 Activity 栈去管理和启动 Activity 的这个流程
ActivityRcord 

创建 ActivityRcord 之后，利用 RootWindowContainer 去管理 ActivityWindow 的显示状态，（除了启动，恢复显示也会经过这个 RootWindowContainer）

首先会从 RootWindowContainer 进入 ActivityStack 

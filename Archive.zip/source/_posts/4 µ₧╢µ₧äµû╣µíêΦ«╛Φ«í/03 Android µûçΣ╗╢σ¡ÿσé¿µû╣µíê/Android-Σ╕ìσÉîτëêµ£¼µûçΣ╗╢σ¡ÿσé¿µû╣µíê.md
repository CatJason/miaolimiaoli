---
title: Android 音视频屏幕旋转方案
categoriesWeight: 5.1
weight: 5
categories: 
   - 4 - 架构方案设计
   - 4.2 - Android 存储文件方案设计
---

Q：我应该去哪里获取不同版本的存储策略

A：要获取不同版本的 Android 存储策略（Storage Policies），您可以访问以下资源，这些资源提供了详细的版本特定存储策略和变更的信息：

### 官方 Android 文档
Android 官方文档是了解不同版本存储策略最可靠的来源。以下是一些重要的链接：

1. **[Android Developers Storage Documentation](https://developer.android.com/guide/topics/data/data-storage)**：
   这是 Android 官方的存储文档，涵盖了各种存储选项和最佳实践。
   
2. **[Android Platform Releases](https://developer.android.com/about/versions)**：
   这个页面提供了每个 Android 版本的详细变更，包括存储策略的变更。

3. **[Scoped Storage](https://developer.android.com/training/data-storage)**：
   针对 Android 10（API Level 29）及更高版本的分区存储（Scoped Storage），是存储策略的重要变更点。

### 官方博客和公告
Android 官方博客和公告也是了解存储策略变更的好资源：

1. **[Android Developers Blog](https://android-developers.googleblog.com/)**：
   在这个博客上，Google 发布了关于新功能和存储策略变更的详细信息和指导。

### GitHub 和社区资源
开源社区和开发者论坛也提供了大量关于存储策略的信息：

1. **[Google Samples on GitHub](https://github.com/android/sunflower)**：
   Google 提供的示例项目，可以查看不同版本的存储策略实现。

2. **[Stack Overflow](https://stackoverflow.com/)**：
   搜索关于 Android 存储策略的问题和答案，可以获取社区的解决方案和建议。

### 具体版本的存储策略变更
要了解具体版本的存储策略变更，可以参考以下步骤：

1. **访问 Android 开发者文档中的版本变更日志**：
   每个 Android 版本的变更日志会详细列出该版本的新特性和变更，包括存储策略。

2. **查找特定版本的存储策略文档**：
   在 Android Developers 网站上，您可以找到特定版本的 API 参考和变更日志。

### 直接搜索具体问题
如果您有特定的存储策略问题，可以直接在 Google 搜索：

- 例如：`Android 10 Scoped Storage`
- 例如：`Android 11 Storage Policy Changes`

通过这些资源，您应该能够找到详细的 Android 存储策略信息，并理解每个版本的特定变更。

# Android 6 以下的文件存储和读取策略

在Android 6.0（API Level 23）及以下版本中，文件存储和读取的策略主要涉及以下几个方面：

### 1. 存储位置
Android系统提供了两种主要的存储位置：内部存储和外部存储。

#### 内部存储
- 内部存储是应用的私有存储区域，只有该应用可以访问。
- 存储在内部存储中的文件默认在应用卸载时会被删除。
- 使用`Context`对象的方法可以在内部存储中读写文件，例如：
  - `openFileOutput(String name, int mode)`：写文件
  - `openFileInput(String name)`：读文件

#### 外部存储
- 外部存储可以是设备的外部存储卡或者内置存储分区。
- 分为公共外部存储和应用私有外部存储。
- 公共外部存储可以被所有应用访问，例如图片、音频文件等。
- 应用私有外部存储只能被创建该文件的应用访问，在应用卸载时会被删除。
- 使用`Environment`类和`Context`对象的方法可以在外部存储中读写文件，例如：
  - `getExternalFilesDir(String type)`：获取应用私有外部存储目录
  - `Environment.getExternalStoragePublicDirectory(String type)`：获取公共外部存储目录

### 2. 权限管理
在Android 6.0及以下版本中，应用需要在`AndroidManifest.xml`中声明对外部存储的读写权限：
- 读权限：`<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>`
- 写权限：`<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>`

这些权限在应用安装时由用户批准。

### 3. 文件操作代码示例

#### 内部存储
写文件：
```java
String filename = "myfile.txt";
String fileContents = "Hello, world!";
FileOutputStream fos = openFileOutput(filename, Context.MODE_PRIVATE);
fos.write(fileContents.getBytes());
fos.close();
```

读文件：
```java
FileInputStream fis = openFileInput(filename);
InputStreamReader isr = new InputStreamReader(fis);
BufferedReader bufferedReader = new BufferedReader(isr);
StringBuilder sb = new StringBuilder();
String line;
while ((line = bufferedReader.readLine()) != null) {
    sb.append(line);
}
String fileContents = sb.toString();
fis.close();
```

#### 外部存储
检查存储状态：
```java
String state = Environment.getExternalStorageState();
if (Environment.MEDIA_MOUNTED.equals(state)) {
    // 可以读写外部存储
}
```

写文件：
```java
File file = new File(getExternalFilesDir(null), "myfile.txt");
FileOutputStream fos = new FileOutputStream(file);
fos.write(fileContents.getBytes());
fos.close();
```

读文件：
```java
File file = new File(getExternalFilesDir(null), "myfile.txt");
FileInputStream fis = new FileInputStream(file);
InputStreamReader isr = new InputStreamReader(fis);
BufferedReader bufferedReader = new BufferedReader(isr);
StringBuilder sb = new StringBuilder();
String line;
while ((line = bufferedReader.readLine()) != null) {
    sb.append(line);
}
String fileContents = sb.toString();
fis.close();
```

这些代码示例展示了在Android 6.0及以下版本中如何进行基本的文件读写操作。随着Android版本的升级，文件存储和权限管理策略也发生了显著变化，因此在开发过程中需要根据目标API版本进行适配。

# Android 6 以上文件存储和读取策略

在Android 6.0（API Level 23）及以上版本中，文件存储和读取策略发生了一些变化，特别是在权限管理和存储位置的使用方面。以下是各版本的策略变化和相应的文件存储读写方法。

### 1. Android 6.0 (API Level 23)
#### 动态权限
- 从Android 6.0开始，权限管理采用动态权限模式。用户可以在运行时授予或拒绝权限。
- 应用在使用外部存储时，需要在`AndroidManifest.xml`中声明权限，并在运行时请求权限。

**权限请求代码示例：**
```java
if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        != PackageManager.PERMISSION_GRANTED) {
    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE);
}
```

### 2. Android 7.0 (API Level 24)
#### 文件URI策略
- 从Android 7.0开始，`File` URI不再被允许在应用之间共享。必须使用`FileProvider`来共享文件URI。

**`FileProvider`配置示例：**
在`AndroidManifest.xml`中：
```xml
<provider
    android:name="androidx.core.content.FileProvider"
    android:authorities="${applicationId}.fileprovider"
    android:exported="false"
    android:grantUriPermissions="true">
    <meta-data
        android:name="android.support.FILE_PROVIDER_PATHS"
        android:resource="@xml/file_paths" />
</provider>
```
在`res/xml/file_paths.xml`中：
```xml
<paths>
    <external-path name="external_files" path="." />
</paths>
```

### 3. Android 8.0 (API Level 26)
#### 安全性增强
- 在后台执行文件操作受到限制，必须在前台任务或通过服务进行文件操作。

### 4. Android 9.0 (API Level 28)
#### 共享存储访问
- 在Android 9.0中引入了新的API，用于访问共享存储，推荐使用`ACTION_OPEN_DOCUMENT`和`ACTION_CREATE_DOCUMENT`来访问和创建文件。

**使用示例：**
```java
Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
intent.addCategory(Intent.CATEGORY_OPENABLE);
intent.setType("*/*");
startActivityForResult(intent, REQUEST_CODE_OPEN_DOCUMENT);
```

### 5. Android 10 (API Level 29)
#### 分区存储 (Scoped Storage)
- 引入了分区存储，应用只能访问其私有的外部存储空间，除非使用特定的API访问公共存储。
- 可以通过请求Legacy存储模式来继续使用传统的存储访问方式（直到Android 11）。

**分区存储代码示例：**
```java
File file = new File(getExternalFilesDir(null), "myfile.txt");
FileOutputStream fos = new FileOutputStream(file);
fos.write(fileContents.getBytes());
fos.close();
```

### 6. Android 11 (API Level 30)
#### 强制分区存储
- 强制启用分区存储，应用无法再使用`requestLegacyExternalStorage`标志。
- 提供了新的访问存储的API，如`MediaStore`。

**MediaStore使用示例：**
```java
ContentValues values = new ContentValues();
values.put(MediaStore.MediaColumns.DISPLAY_NAME, "myfile.txt");
values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS);
Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
if (uri != null) {
    OutputStream outputStream = getContentResolver().openOutputStream(uri);
    outputStream.write(fileContents.getBytes());
    outputStream.close();
}
```

### 7. Android 12 (API Level 31) 及更高版本
#### 进一步限制外部存储访问
- 在Android 12中，对特定类型的文件访问进行了更多的限制，需要使用特定的API来访问不同类型的文件，如音频、视频和图片等。

**总结：**
- Android 6.0及以上版本在权限管理上采用动态权限，需要在运行时请求权限。
- Android 7.0开始引入`FileProvider`来共享文件URI。
- Android 10引入分区存储，Android 11强制启用分区存储，进一步限制了应用对外部存储的访问。
- 使用`MediaStore`等新的API来进行文件的读写操作，以适应最新的存储策略。

了解并适应这些变化，可以确保应用在不同Android版本上的文件存储和读取操作安全且有效。
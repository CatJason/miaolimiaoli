---
title: Android aar 文件到底是什么
categoriesWeight: 7.1
weight: 1
categories: 
   - 6 - Android 打包编译
   - 6.1 - 文件分析
---

作者: 朕小猫与GPT4

# 问题起源：怎么打包发布一个含有 C++ 文件的 Library

起因是 KOOM 2.2.1 Release 存在后台分析进程在部分机型失效，想自己发布一个适合自己项目的版本。

# .so文件可以被打包到最终的AAR文件中吗

是的，`.so`文件可以并且通常被打包到最终的AAR（Android Archive）文件中。AAR文件是Android开发中用于分发Android库的标准格式，它包含了库所需的所有资源、编译后的代码以及其他文件，比如`.so`文件（本地库文件）。

### 打包`.so`文件到AAR中的步骤

1. **放置`.so`文件**: 将你的`.so`文件放置在项目的`src/main/jniLibs/`目录下。按照不同的CPU架构，你可能需要创建相应的子目录，例如`armeabi-v7a`、`arm64-v8a`、`x86`等，然后将相应架构的`.so`文件放置在这些目录下。

2. **配置Gradle构建脚本**: 确保你的`build.gradle`文件正确配置，这样Gradle在构建过程中就会自动将`jniLibs`目录下的`.so`文件包括到AAR包中。大多数情况下，这个过程是自动完成的，无需额外配置。

### 示例目录结构

```crystal
YourLibraryProject/
├── src/
│   └── main/
│       ├── java/
│       │   └── ... (your Java or Kotlin source files)
│       ├── res/
│       │   └── ... (your resources)
│       └── jniLibs/
│           ├── armeabi-v7a/
│           │   └── libyourlibrary.so
│           ├── arm64-v8a/
│           │   └── libyourlibrary.so
│           ├── x86/
│           │   └── libyourlibrary.so
│           └── x86_64/
│               └── libyourlibrary.so
```

### 构建AAR包

当你构建你的库时（例如，通过运行`./gradlew assembleRelease`），Gradle会自动将`jniLibs`目录下的所有`.so`文件包括到生成的AAR文件中。这样，当其他开发者将你的AAR文件作为依赖项添加到他们的项目中时，这些`.so`文件就会被自动解压到正确的位置，供他们的应用使用。

确保在发布你的库之前测试它，以确保`.so`文件被正确包含且可以按预期工作。这通常涉及到在包含不同CPU架构设备的模拟器或真实设备上运行和测试你的库。

# .aar 里可以有哪些文件

一个AAR（Android Archive）文件是Android库项目的发布包格式，用于在开发者之间共享Android库。AAR文件包含了库所需要的所有内容，使其可以被其他的Android应用项目引用。以下是AAR文件通常包含的文件和目录：

### 必需的内容

- `classes.jar`：包含库的所有编译后的Java类（.class文件）。
- `res/`：包含库所使用的所有资源文件，如布局（layouts）、字符串（strings）、图片（drawables）等。
- `AndroidManifest.xml`：库的Android清单文件，描述了库的包名、所需权限、活动（activities）、服务（services）等。

### 可选的内容

- `R.txt`：包含库中所有资源的ID名称和类型的列表，这是为了在库被引用时帮助生成最终应用的R类。
- `aidl/`：包含库所使用的所有AIDL（Android Interface Definition Language）文件，用于定义跨进程通信接口。
- `assets/`：包含可以被库访问的原始文件，如文本、音频或视频文件。
- `libs/*.jar`：包含库依赖的任何Java库的JAR文件。
- `jni/` 或 `jniLibs/`：包含库依赖的本地库（如`.so`文件），这些文件根据不同的CPU架构可能存放在不同的子目录下，如`armeabi-v7a/`、`arm64-v8a/`等。
- `proguard.txt`：包含用于代码混淆的ProGuard规则。
- `lint.jar`：包含自定义lint检查规则的JAR，这些规则可以在使用库的项目中被lint程序使用。
- `public.txt`：列出了库公开的资源ID，这些资源ID在库的使用者中是可见的。
- `annotations.zip`：包含用于工具支持的注解，比如nullability注解等。

### 如何查看AAR文件内容

你可以通过解压AAR文件（它本质上是一个ZIP文件）来查看里面的内容。使用任何标准的压缩文件管理器，如WinRAR、7-Zip等，都可以打开AAR文件并浏览其中的内容。

### 使用AAR文件

当你将AAR文件作为依赖项添加到Android项目中时，项目构建系统（如Gradle）会自动处理并引入这些内容，包括解析资源、合并清单文件等，从而使库中的功能可用于应用程序。
[![aar文件分析.png](https://s21.ax1x.com/2024/03/10/pFy2w6J.png)](https://imgse.com/i/pFy2w6J)
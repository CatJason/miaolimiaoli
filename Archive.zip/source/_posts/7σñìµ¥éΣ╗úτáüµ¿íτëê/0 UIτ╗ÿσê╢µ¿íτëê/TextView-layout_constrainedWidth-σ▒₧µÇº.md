---
title: TextView layout_constrainedWidth 属性
categoriesWeight: 8
weight: 1
categories: 
   - 7 - 复杂代码模版
   - 7.1 - UI 绘制模版
---

`layout_constrainedWidth`是`ConstraintLayout`中的一个属性，用于在处理宽度约束时提供更多的灵活性和控制。当你使用`ConstraintLayout`构建复杂的布局时，可能会遇到某些视图在其内容过长时需要被约束宽度的情况，以避免它们超出屏幕边界或影响其他视图的布局。`layout_constrainedWidth`属性就是为了解决这类问题而设计的。

```xml
<androidx.constraintlayout.widget.ConstraintLayout 		         xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <TextView
        android:id="@+id/textView"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        app:layout_constrainedWidth="true"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toStartOf="@id/buttonView"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintHorizontal_chainStyle="packed"
        app:layout_constraintHorizontal_bias="0"
        android:text="长文本示例长文本示例长文本示例长文本示例长文本示例长文本示例长文本示例长文本示例长文本示例" />

    <Button
        android:id="@+id/buttonView"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        app:layout_constraintStart_toEndOf="@id/textView"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintHorizontal_chainStyle="packed"
        app:layout_constraintHorizontal_bias="0"
        android:text="按钮" />

</androidx.constraintlayout.widget.ConstraintLayout>
```
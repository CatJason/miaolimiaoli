---
title: About Author
date: 2023-08-09 11:40:47
comments: false
type: "about"
layout: "about"
---

![Author](https://avatars.githubusercontent.com/u/37769898?v=4)